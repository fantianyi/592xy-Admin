<?php
return array(
    
    'TMPL_PARSE_STRING'=>array('__PUBLIC__'=>'/Admin/Public'), 

);
?>