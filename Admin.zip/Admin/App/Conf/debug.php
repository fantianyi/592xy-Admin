<?php
return array(
    'SHOW_RUN_TIME'=>true,            // 运行时间显示
    'SHOW_ADV_TIME'=>true,            // 显示详细的运行时间
    'SHOW_DB_TIMES'=>true,            // 显示数据库查询和写入次数
    'SHOW_CACHE_TIMES'=>true,        // 显示缓存操作次数
    'SHOW_USE_MEM'=>true,            // 显示内存开销
    'SHOW_PAGE_TRACE'=>true            //显示调试信息
);
?>