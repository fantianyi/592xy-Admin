<?php
// 会员充值模块
class RechargeAction extends CommonXYAction {
    public $displayName = '会员充值记录';

    function _filter(&$map){
        //$map['id'] = array('egt',2);
        //$map['account'] = array('like',"%".$_POST['account']."%");
        
        if($_GET['id']!=''){
            $map['member_id']=$_GET['id'];
        }
    }
            
}
?>