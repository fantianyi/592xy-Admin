<?php
// 会员模块
class DemoMemberAction extends MemberAction {
    public $displayName = '演示会员账户资料';
}
?>