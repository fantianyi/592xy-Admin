<?php
class CommonXYAction extends CommonAction {
    public $displayName = '';
    
    // 插入数据
    public function insert() {
        // 创建数据对象
        $name = $this->getActionName();
        $model = D ($name);
        if(!$model->create()) {
            $this->error($model->getError());
        }else{
            // 写入帐号数据
            $model->__set("id", array('exp','UUID_SHORT()'));  
            //dump($model);
            if($result = $model->add()) {
                $this->success($displayName . '添加成功！');
            }else{
                $this->error($displayName . '添加失败！');
            }
        }
    }
}
?>