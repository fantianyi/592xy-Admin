<?php
// 用户模型
class DemoMemberModel extends MemberModel {
    protected $tablePrefix = 'dwz_';
}
?>