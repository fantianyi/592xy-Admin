<?php
// 用户模型
class MemberModel extends CommonModel {
    protected $tablePrefix = 'xy_';

    public $_validate = array(
        array('uid','/^[a-z]\w{3,}$/i','帐号格式错误'),
        array('uid','','帐号已经存在',self::EXISTS_VALIDATE,'unique',self::MODEL_INSERT),
        array('pwd','require','密码必须'),
        //array('nickname','require','昵称必须'),
    );

    public $_auto = array(
        array('password','pwdHash',self::MODEL_BOTH,'callback'),
        array('create_time','time',self::MODEL_INSERT,'function'),
        array('update_time','time',self::MODEL_UPDATE,'function'),
        );

    protected function pwdHash() {
        if(isset($_POST['password'])) {
            return pwdHash($_POST['password']);
        }else{
            return false;
        }
    }

    function hasRole($userId) {
        $table = $this->tablePrefix.'role_user';
        $rs = $this->db->query('select role_id from '.$table.' where user_id='.$userId);
        if (isset($rs)) {
            return true;
        }
        return false;
    }
}
?>